import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_compress/video_compress.dart';
import 'dart:developer' as developer;
// ignore: library_prefixes
import 'package:image_picker/image_picker.dart' as imagePicker;
import 'package:video_compression/utility/format_bytes.dart';
import 'package:video_player/video_player.dart';
part 'video_event.dart';
part 'video_state.dart';

class VideoBloc extends Bloc<VideoEvent, VideoState> {
  VideoBloc() : super(VideoInitial()) {
    on<CompressVideo>((event, emit) async {
      File file;
      MediaInfo? mediaInfo;
      String fileSize;
      try {
        final picker = imagePicker.ImagePicker();
        developer.log('message1');
        // ignore: deprecated_member_use
        imagePicker.XFile? video =
            await picker.pickVideo(source: imagePicker.ImageSource.gallery);
        // PickedFile? pickedFile = await picker.getVideo(source: ImageSource.gallery);
        developer.log('message2');

        file = File(video!.path);

        await VideoCompress.setLogLevel(0);

        emit(LoadingState(loaderstate: LoaderState.compressing));

        mediaInfo = await VideoCompress.compressVideo(
          file.path,
          quality: event.quality,
          deleteOrigin: false,
          includeAudio: true,
        );
        developer.log(mediaInfo!.filesize!.toString());

        fileSize = formatBytes(mediaInfo.filesize!, 2);

        emit(VideoCompressed(
            mediaInfo: mediaInfo, success: true, fileSize: fileSize));
        print('sfeverw');
       
      } catch (e, t) {
        developer.log(e.toString());
        developer.log(t.toString());
        emit(VideoCompressed(
            mediaInfo: null, success: false, fileSize: '$e, $t'));
      }
    });

    on<UploadVideo>((event, emit) async {
      emit(LoadingState(loaderstate: LoaderState.compressing));
      try {
        // var res = await uploadVideo(event.file);
        // .then((value) {
        developer.log('video uploaded');
        emit(VideoUploaded(
          url: 'dfg',
          success: true,
        ));
      } catch (e, t) {
        // }).onError((error, stackTrace) {
        developer.log('video not uploaded');
        developer.log('$e, $t');
        emit(VideoUploaded(
          url: 'dfg',
          success: false,
        ));
        // });
        // });
      }
    });
  }

}
